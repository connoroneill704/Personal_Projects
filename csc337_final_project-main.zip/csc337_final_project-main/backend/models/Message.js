/* 
Names: Connor O'Neill, Jace Sullivan, Jason Cantor
Model for a message to send
Contains all of the fields that a user can input
*/
const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  sender: { type: String, required: true },
  receiver: { type: String, required: true },
  content: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Message', MessageSchema);
